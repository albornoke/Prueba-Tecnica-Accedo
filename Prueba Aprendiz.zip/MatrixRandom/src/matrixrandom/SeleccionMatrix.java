/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package matrixrandom;
import java.util.Random;
/**
 *
 * @author bryan_valencia
 */
public class SeleccionMatrix {
 private final int[][] matrix = new int[10][5];
    private boolean[] filaPunto = new boolean[10];
    private boolean[] columnaPunto = new boolean[5];
    private final int seleccionMaxima = 5;
    private int numeroSeleccionado = 0;

     
    
    public SeleccionMatrix() {
        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 5; j++) {
                matrix[i][j] = 0;
            }
        }
    }

    public void seleccionPuntoAleatorio() {
        Random random = new Random();
        int row = random.nextInt(10);
        int col = random.nextInt(5);

        
        if (filaPunto[row] || columnaPunto[col]) {
            return;
        }

        
        matrix[row][col] = 1;
        filaPunto[row] = true;
        columnaPunto[col] = true;
        numeroSeleccionado++;
    }

    public void imprimirMatrix() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }   
}
