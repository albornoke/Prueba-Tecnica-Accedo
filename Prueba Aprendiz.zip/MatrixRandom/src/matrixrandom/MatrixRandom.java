/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package matrixrandom;
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author bryan_valencia
 */
public class MatrixRandom {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       SeleccionMatrix matrix = new SeleccionMatrix();
        for (int i = 0; i < 5; i++) {
            matrix.seleccionPuntoAleatorio();
        }
        matrix.imprimirMatrix();
    
    }
    
}
