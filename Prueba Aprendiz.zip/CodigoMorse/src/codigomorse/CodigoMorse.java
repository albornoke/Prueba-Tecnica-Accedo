/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package codigomorse;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author bryan_valencia
 */
public class CodigoMorse {
    private static final Map<Character, String> CODIGO_MORSE;
    private static final Map<String, Character> MORSE_CODIGO;

    static {
        CODIGO_MORSE = new HashMap<>();
        CODIGO_MORSE.put('a', ".-");
        CODIGO_MORSE.put('b', "-...");
        CODIGO_MORSE.put('c', "-.-.");
        CODIGO_MORSE.put('d', "-..");
        CODIGO_MORSE.put('e', ".");
        CODIGO_MORSE.put('f', "..-.");
        CODIGO_MORSE.put('g', "--.");
        CODIGO_MORSE.put('h', "....");
        CODIGO_MORSE.put('i', "..");
        CODIGO_MORSE.put('j', ".---");
        CODIGO_MORSE.put('k', "-.-");
        CODIGO_MORSE.put('l', ".-..");
        CODIGO_MORSE.put('m', "--");
        CODIGO_MORSE.put('n', "-.");
        CODIGO_MORSE.put('o', "---");
        CODIGO_MORSE.put('p', ".--.");
        CODIGO_MORSE.put('q', "--.-");
        CODIGO_MORSE.put('r', ".-.");
        CODIGO_MORSE.put('s', "...");
        CODIGO_MORSE.put('t', "-");
        CODIGO_MORSE.put('u', "..-");
        CODIGO_MORSE.put('v', "...-");
        CODIGO_MORSE.put('w', ".--");
        CODIGO_MORSE.put('x', "-..-");
        CODIGO_MORSE.put('y', "-.--");
        CODIGO_MORSE.put('z', "--..");
        CODIGO_MORSE.put('0', "-----");
        CODIGO_MORSE.put('1', ".----");
        CODIGO_MORSE.put('2', "..---");
        CODIGO_MORSE.put('3', "...--");
        CODIGO_MORSE.put('4', "....-");
        CODIGO_MORSE.put('5', ".....");
        CODIGO_MORSE.put('6', "-....");
        CODIGO_MORSE.put('7', "--...");
        CODIGO_MORSE.put('8', "---..");
        CODIGO_MORSE.put('9', "----.");
        CODIGO_MORSE.put(' ', "/");

        MORSE_CODIGO = new HashMap<>();
        for (Map.Entry<Character, String> entry : CODIGO_MORSE.entrySet()) {
            MORSE_CODIGO.put(entry.getValue(), entry.getKey());
        }
    }
    public String toMorseCodigo(String text) {
        StringBuilder resultado = new StringBuilder();
        for (char c : text.toLowerCase().toCharArray()) {
            if (CODIGO_MORSE.containsKey(c)) {
                resultado.append(CODIGO_MORSE.get(c)).append(" ");
            }
        }
        return resultado.toString().trim();
    }

    public String formaMorseCodigo(String morseCodigo) {
        StringBuilder resultado = new StringBuilder();
        String[] morseCodigoArray = morseCodigo.split(" ");
        for (String morse : morseCodigoArray) {
            if (MORSE_CODIGO.containsKey(morse)) {
                resultado.append(MORSE_CODIGO.get(morse));
            }
            if (morse.equals("/")) {
                resultado.append(" ");
            }
        }
        return resultado.toString();
    }
    public static void main(String[] args) {
        CodigoMorse traductorCodigoMorse = new CodigoMorse();
        String morseCode = traductorCodigoMorse.toMorseCodigo("HEY JUDE");
        System.out.println(morseCode);
        String text = traductorCodigoMorse.formaMorseCodigo(morseCode + " /");
        System.out.println(text);
    }
    
}
